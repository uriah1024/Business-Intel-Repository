import com.follett.fsc.core.k12.tools.procedures.ProcedureJavaSource;
import com.follett.fsc.core.k12.web.AppConstants;
import com.follett.fsc.core.k12.web.AppGlobals;
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.utils.X2BaseException;

public class GetEmailConfig extends ProcedureJavaSource 
{

	private static final long serialVersionUID = 1L;

	private static final String RUN_ON_APP_PARAM = "runOnApp";
	
	public Boolean m_runOnApp = false;
	
	@Override
	protected void execute() throws Exception 
	{
		String deploymentId = getBroker().getPersistenceKey().getDeploymentId();
		
		logMessage("email.address =       " + AppGlobals.getConfigProperty(AppConstants.EMAIL_SENDADDRESS, deploymentId));
		logMessage("email.password =      " + AppGlobals.getConfigProperty(AppConstants.EMAIL_SENDPASSWORD, deploymentId));
		logMessage("email.smtpAddress =   " + AppGlobals.getConfigProperty(AppConstants.EMAIL_SMTPADDRESS, deploymentId));
		logMessage("email.smtpPort =      " + AppGlobals.getConfigProperty(AppConstants.EMAIL_SMTPPORT, deploymentId));
		logMessage("email.useSsl =        " + AppGlobals.getConfigProperty(AppConstants.EMAIL_USESSL, deploymentId));
		logMessage("email.useTls =        " + AppGlobals.getConfigProperty(AppConstants.EMAIL_USETLS, deploymentId));
		logMessage("email.anonymousAuth = " + AppGlobals.getConfigProperty(AppConstants.EMAIL_ANONYMOUS_AUTH, deploymentId));
		logMessage("email.smtp.debug =    " + AppGlobals.getConfigProperty(AppConstants.EMAIL_SMTP_DEBUG, deploymentId));
		
	}

	@Override
	protected void initialize() throws X2BaseException 
	{
		super.initialize();
		m_runOnApp = (Boolean) getParameter(RUN_ON_APP_PARAM);
	}
	
	@Override
	protected void saveState(UserDataContainer userData) throws X2BaseException
	{
		
		if (m_runOnApp)
		{
			runOnApplicationServer();
		}
	}
}