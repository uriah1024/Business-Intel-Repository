import java.util.List;
import java.util.TreeMap;

import org.apache.ojb.broker.query.QueryByCriteria;

import com.follett.fsc.core.framework.persistence.X2Criteria;
import com.follett.fsc.core.k12.business.PreferenceManager;
import com.follett.fsc.core.k12.business.StudentManager;
import com.follett.fsc.core.k12.business.X2Broker;
import com.follett.fsc.core.k12.tools.procedures.ProcedureJavaSource;
import com.follett.fsc.core.k12.web.ApplicationContext;
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.sis.model.beans.AcademicTrack;
import com.x2dev.sis.model.beans.AcademicTrackGrade;
import com.x2dev.sis.model.beans.SisPreferenceConstants;
import com.x2dev.sis.model.beans.SisStudent;
import com.x2dev.sis.model.beans.StudentScheduleAttributes;
import com.x2dev.sis.model.business.StudentRequestEntryManager;
import com.x2dev.utils.X2BaseException;
import com.x2dev.utils.types.PlainDate;

public class OpenEntryModeTestProcedure extends ProcedureJavaSource
{
	
	private UserDataContainer m_userData;

	@Override
	protected void execute() throws Exception
	{
		logMessage("Assuming you are in a school context and your filter is set to Build Year:");
		boolean openEntryMode = false;
        SisStudent student = getStudent(m_userData);
        
        logMessage("Testing entry failure point for Student: " + student.getNameView());
        
        String allowRequestEntry = PreferenceManager.getPreferenceValue(m_userData.getOrganization().getRootOrganization(),
                SisPreferenceConstants.SCH_REQUEST_ENTRY_ENABLED);
        
        logMessage("Allow request entry (district preference) must be true. It is: " + allowRequestEntry);

        if ("true".equalsIgnoreCase(allowRequestEntry))
        {
            AcademicTrackGrade trackGrade = getTrackGrade(student, getBroker());
            if (trackGrade != null)
            {
            	logMessage("Academic Track Grade found: OID: " + trackGrade.getOid() + " Start date: " + trackGrade.getStartDate() + " End date: " + trackGrade.getEndDate());
            }
            else
            {
            	logMessage("Academic Track Grade not found. If no errors found above, check the following:");
            	logMessage("There is an academic track type that matches the student's academic track of: " + student.getAcademicTrackType());
            	logMessage("The academic track of that type is not limited to secondary students only");
            	logMessage("The academic track of that type has a matching grade level to the student's next grade level AND there's entry dates");
            }
            
            if (trackGrade != null && trackGrade.getStartDate() != null && trackGrade.getEndDate() != null) 
            {
                if (m_userData.getSessionNavConfig().getApplicationContext() == ApplicationContext.SCHOOL)
                {
                    openEntryMode = true;
                }
                else
                {
                    PlainDate startDate = trackGrade.getStartDate();
                    PlainDate endDate = trackGrade.getEndDate();
                    
                    PlainDate date = new PlainDate(m_userData.getTimeZone());
                    
                    if (date.compareTo(startDate) >= 0 && date.compareTo(endDate) <=0)
                    {
                        openEntryMode = true;
                    }
                }
            }
        }
        
        logMessage("Open entry mode: " + openEntryMode);

	}
	
	@Override
	protected void saveState(UserDataContainer userData) throws X2BaseException
	{
		m_userData = userData;
	}
	
    private SisStudent getStudent(UserDataContainer userData)
    {
        SisStudent student = null;
        
        if (userData.getSessionNavConfig().getApplicationContext() == ApplicationContext.STUDENT)
        {
            student = (SisStudent) userData.getStudent();
        }
        else if (userData.getParentList() != null)
        {
            if (StudentScheduleAttributes.class.equals(userData.getParentList().getDataClass()))
            {
                student = ((StudentScheduleAttributes) userData.getParentList().getCurrentRecord()).getStudent();
            }
            else
            {
                student = (SisStudent) userData.getParentList().getCurrentRecord();
            }
        }
        
        return student;
    }

    private AcademicTrackGrade getTrackGrade(SisStudent student, X2Broker broker)
    {
        AcademicTrackGrade trackGrade = null;
        logMessage("Obtaining academic track grade (School view, Schedule > Academic Tracks > Details > Grade Level)");
        logMessage("Next school must be set. Next school's OID: " + student.getNextSchoolOid());
        logMessage("Next school must have a build context: " + (student.getNextSchool() != null ? student.getNextSchool().getBuildContext() : "Null next school"));
        if (student != null && student.getNextSchool() != null && student.getNextSchool().getBuildContext() != null)
        {
            TreeMap sortedGradeLevels = StudentManager.buildGradeLevelMap(broker);
            int maxGradeLevel = StudentManager.getMaxGradeLevel(broker);
            logMessage("Max grade level: " + maxGradeLevel);
            
            List matchingGradeLevels = StudentManager.getMatchingGradeLevels(maxGradeLevel, student.getYog(), student.getNextSchool().getBuildContext().getSchoolYear(), sortedGradeLevels);
            String nextGradeLevel = matchingGradeLevels.size() == 1  ? (String) matchingGradeLevels.get(0) : null;
            logMessage("Next grade level (must be less than or equal to the max grade level): " + nextGradeLevel);
            if (nextGradeLevel == null)
            {
            	logMessage("Next grade level returned null because: " + (matchingGradeLevels == null ? 
            			"There were no matching grade levels for the next numeric level or it was over the max grade level" : 
            				"There was more than one grade level for the next numeric grade"));
            }
    
            X2Criteria trackGradeCriteria = new X2Criteria();
            trackGradeCriteria.addEqualTo(AcademicTrackGrade.REL_ACADEMIC_TRACK + "." + AcademicTrack.COL_SCHOOL_OID, student.getNextSchoolOid());
            trackGradeCriteria.addEqualTo(AcademicTrackGrade.REL_ACADEMIC_TRACK + "." + AcademicTrack.COL_SECONDARY_STUDENT_ONLY_INDICATOR, Boolean.FALSE);
            trackGradeCriteria.addEqualTo(AcademicTrackGrade.COL_GRADE_LEVEL, nextGradeLevel);
            
            //T20146663 - Requests for build year not showing in School View when school is not using academic tracks
            trackGradeCriteria.addEqualTo(AcademicTrackGrade.REL_ACADEMIC_TRACK + "." + AcademicTrack.COL_TYPE, student.getAcademicTrackType());
    
            QueryByCriteria trackGradeQuery = new QueryByCriteria(AcademicTrackGrade.class, trackGradeCriteria);
            trackGradeQuery.addOrderByAscending(AcademicTrackGrade.COL_END_DATE);
            
            trackGrade = (AcademicTrackGrade) broker.getBeanByQuery(trackGradeQuery);
        }
        
        return trackGrade;
    }
}